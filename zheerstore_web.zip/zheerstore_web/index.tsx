import React, { useState } from "react";

export default function ZheerStore() {
  const [cart, setCart] = useState<number>(0);

  const addToCart = () => {
    setCart((prev) => prev + 1);
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-black via-green-950 to-black text-white font-sans overflow-hidden relative">
      <div
        className="absolute inset-0 opacity-20 bg-cover bg-center"
        style={{
          backgroundImage:
            "url('https://images.unsplash.com/photo-1511512578047-dfb367046420?q=80&w=1200')",
        }}
      />

      <header className="relative z-10 flex items-center justify-between p-6 border-b border-green-500/20 backdrop-blur-xl bg-black/30 sticky top-0">
        <h1 className="text-3xl font-extrabold text-green-400 tracking-[6px] drop-shadow-lg">
          ZHEER STORE
        </h1>

        <div className="flex gap-3 items-center flex-wrap">
          <button className="border border-green-400 px-5 py-2 rounded-2xl hover:bg-green-400 hover:text-black transition-all duration-300">
            Home
          </button>

          <button className="bg-green-400 text-black px-5 py-2 rounded-2xl font-bold">
            Checkout 🛒 ({cart})
          </button>

          <div className="flex gap-2">
            <button className="border border-white/20 bg-white/10 px-5 py-2 rounded-2xl">
              Login
            </button>

            <button className="bg-white text-black px-5 py-2 rounded-2xl font-semibold">
              Register
            </button>
          </div>
        </div>
      </header>

      <section className="relative z-10 text-center py-24 px-6">
        <h2 className="text-5xl md:text-7xl font-black text-green-300">
          TOKO ONLINE
          <br />
          ZHEER STORE
        </h2>

        <p className="mt-6 text-gray-300 max-w-2xl mx-auto text-lg">
          Website toko online Zheer Store untuk App Premium, ID FF Cantik, dan Akun Game.
        </p>
      </section>
    </div>
  );
}
